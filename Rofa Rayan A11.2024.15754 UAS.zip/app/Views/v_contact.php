<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php
$lorem = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ";

echo str_repeat($lorem, 25);
?>
<?= $this->endSection() ?>